package hu.elte.Tippmix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TippmixApplicationTests {

	@Test
	void contextLoads() {
	}

}

package hu.elte.Tippmix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TippmixApplication {

	public static void main(String[] args) {
		SpringApplication.run(TippmixApplication.class, args);
	}

}
